﻿namespace OSAE.$safeprojectname$
{
    using System;
	using System.Text;

    public class $safeprojectname$ : OSAEPluginBase
    {
        /// <summary>
        /// Provides access to logging
        /// </summary>
        Logging logging = Logging.GetLogger("$safeprojectname$");

        /// <summary>
        /// Plugin name
        /// </summary>
        string pName;

        /// <summary>
        /// OSA Plugin Interface - Commands the be processed by the plugin
        /// </summary>
        /// <param name="method">Method containging the command to run</param>
        public override void ProcessCommand(OSAEMethod method)
        {
            // place the plugin command code here leave empty if unable to process commands
        }

        /// <summary>
        /// OSA Plugin Interface - called on start up to allow plugin to do any tasks it needs
        /// </summary>
        /// <param name="pluginName">The name of the plugin from the system</param>
        public override void RunInterface(string pluginName)
        {
            pName = pluginName;

            try
            {
                logging.AddToLog("Starting $safeprojectname$...", true);
                                              
            }
            catch (Exception ex)
            {
                logging.AddToLog("Error during RunInterface: " + ex.Message, true);
            }
        }

        /// <summary>
        /// OSA Plugin Interface - The plugin has been asked to shut down
        /// </summary>        
        public override void Shutdown()
        {
			logging.AddToLog("Stopping $safeprojectname$...", true);
            
			// Place any code required to shut down your plugin here leave empty if no action is required
        }
    }
}
