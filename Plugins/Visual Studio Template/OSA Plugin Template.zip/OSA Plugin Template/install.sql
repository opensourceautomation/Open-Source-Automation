CALL osae_sp_object_type_add ('$safeprojectname$','$safeprojectname$','','$safeprojectname$',0,0,0,1);
CALL osae_sp_object_type_state_add ('OFF','Stopped','$safeprojectname$');
CALL osae_sp_object_type_state_add ('ON','Running','$safeprojectname$');
CALL osae_sp_object_type_event_add ('OFF','Stopped','$safeprojectname$');
CALL osae_sp_object_type_event_add ('ON','Started','$safeprojectname$');
CALL osae_sp_object_type_method_add ('OFF','Stop','$safeprojectname$','','','','');
CALL osae_sp_object_type_method_add ('ON','Start','$safeprojectname$','','','','');